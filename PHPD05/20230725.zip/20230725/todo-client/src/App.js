import React, { Component } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
 
import Index from './components/index.jsx';
import Create from './components/create.jsx';
import Edit from './components/edit.jsx';
import Delete from './components/delete.jsx';
import "bootstrap/dist/css/bootstrap.min.css";

class App extends Component {
  render() {
    return (      
       <BrowserRouter>
        <div>
          <Switch>
             <Route path="/" component={Index} exact/>
             <Route path="/todo/index" component={Index} exact/>
             <Route path="/todo/create" component={Create} exact/>
             <Route path="/todo/edit/:id" component={Edit} />
             <Route path="/todo/delete/:id" component={Delete} />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}
 
export default App;