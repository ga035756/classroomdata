import React from 'react';
import ReactDOM from 'react-dom';
import "bootstrap/dist/css/bootstrap.css";

const element = <h1 className="display-1">Hello World</h1>;
ReactDOM.render(element, document.getElementById("root"));
