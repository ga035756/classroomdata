$("#report").text(Date());

